# 2 号「统一数据」交接包（OSMX 解析库 + 导入页面）

日期：2026-11-02（Asia/Shanghai）。分支：`codex/member-2/osmx-unified-data`（基于 `main` `e3ec3c0`）。**本包未提交、未推送**；按当前用户授权仅交付工作区内容。

## 1. 交付内容

| 类别 | 路径 | 说明 |
| --- | --- | --- |
| 解析库（独立目标） | `src/data/osmx/` | `p1_data_osmx`：OSMX v1 解析、不可变数据集、拓扑/属性查询、缓存、共享 Store；仅依赖 Qt 6 Core |
| 页面模块（独立目标） | `src/app/`（新增文件） | `p1_import_page`：固定路由 ID `import`、公开工厂 `ImportFactory.h`、OSMX 导入适配器、缓存重开加载器 |
| 页面级测试 | `src/app/tests/ImportPageTests.cpp` | CTest 名 `import-page-osmx`，2 个用例 |
| 顶层装配（修改） | 根 `CMakeLists.txt` | `add_subdirectory(src/data/osmx)`、`add_subdirectory(src/app)`、抽出 `p1_ui_common`、`p1_ui` 链接 `p1_import_page` |
| 页面接入（修改） | `src/app/MainWindow.cpp` | 仅把字面量 `"import"` 改为工厂常量与帮助文案，未改窗口架构 |
| 数据契约文档 | `docs/osmx-format.md`、`docs/osmx-storage.md`、`docs/osmx-api.md` | 格式/字段语义、存储清单、3/5 号接口契约 |
| 验证材料 | `docs/verification/assignment2-member2/README.md`、`src/data/osmx/tools/verify-osmx.sh` | Ubuntu 复验步骤、通过标准、缺口清单、一键脚本 |
| 对标记录 | `docs/benchmarks/navit/NAVIT-20261102-2-osmx-import-01.md` | 受阻（未测），不含虚构性能结论 |

## 2. 如何合并

本包包含两部分：

1. `tracked-changes.patch`：已跟踪文件的修改（根 CMake、`ImportFactory/ImportPage/ImportTypes/MainWindow`、项目文档与日志）。
2. `new-files/`：全部新增文件，按仓库相对路径存放。

合并方式（任选其一）：

- 从分支取：在 `codex/member-2/osmx-unified-data` 上查看工作区差异后，由 2 号在获得提交授权时提交，1 号按常规 PR 评审；
- 手工应用：`git apply tracked-changes.patch`，再把 `new-files/` 整目录覆盖到仓库根目录（目录结构与仓库一致）。

注意：补丁基于 `main` `e3ec3c0`；若 `main` 已前进，先 `git apply --3way` 或按文件手工合并，重点检查根 `CMakeLists.txt` 与 `MainWindow.cpp` 的上下文。

## 3. 1 号集成检查清单

- [ ] 根 CMake 已包含 `src/data/osmx` 与 `src/app`，且 `p1_ui` 链接 `p1_import_page`（本包已含）。
- [ ] `MainWindow` 通过 `ImportFactory::pageId()/pageTitle()/pageDescription()/createImportPage()` 注册，固定 ID 为 `import`；不要新增第二个导入入口。
- [ ] 页面在 GUI 线程创建；`registerPage()` 返回 `true` 后所有权归窗口堆栈，返回 `false` 时不要删除其他路由持有的页面。
- [ ] 3/5 号通过 `p1::data::OsmxStore::shared().active()` 读取数据；不要直接读 `data.osmx` 字节或缓存目录。
- [ ] 启动时不需要预热数据：页面在用户导入或“从本机加载所选数据集”后才发布快照（避免启动解析几十 MB）。
- [ ] 若 1 号统一加入 `install()`/打包，`p1_data_osmx`、`p1_import_page` 为静态库，公开头文件在 `src/`、`include/` 下。

## 4. 验证状态（务必按此口径转述）

- **已做（开发主机，非验收）**：Windows 11、Qt 6.11.0、MinGW GCC 13.1.0、CMake 3.30.5、Ninja 1.12.1。
  - Debug 与 Release 各 50/50 目标构建成功，`-Wall -Wextra -Wpedantic` 0 warning；
  - `data-osmx`：18 通过 / 0 失败 / 1 跳过（跳过项为真实文件用例，设置 `P1_OSMX_REAL_FILE` 后单独通过，2.7 s）；
  - `import-page-osmx`：2/2 通过（页面导入合成 `.osmx` + 模拟重启后缓存重开）；
  - 真实 `test.osmx`：头部校验与完整解析通过；912,730 节点 / 121,964 道路 / 1,658 关系 / 44,986 可导航道路 / 536,688 有向边 / 16,408.873 km；SHA-256 `a9c4d90b…6467`；解析+建索引 2,691–2,871 ms（3 次）。
- **未做（不得声称）**：Ubuntu 24.04 / Qt 6.4.2 构建、CTest、Wayland 桌面导入、峰值内存、Navit 对标。
- **复验方式**：在统一 Ubuntu 虚拟机执行 `src/data/osmx/tools/verify-osmx.sh --file <test.osmx>`，归档 `build-osmx/verify-osmx.log` 与截图到 `docs/verification/assignment2-member2/`。

## 5. 边界声明

本包不包含 A*/HMM 路径规划与地图匹配、LinuxRenderer 渲染、算法调用界面、性能监控、主窗口顶层装配、语音导航；这些属 3/5/1/4 号。`test.osmx` 不入 Git，按 SHA-256 随离线包提供。
