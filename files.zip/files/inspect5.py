import struct, sys
sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
data = open(r"D:\Navigation\example\share_for_ubuntu\test.osmx", 'rb').read()

def d(off): return struct.unpack_from('<d', data, off)[0]
def u64(off): return struct.unpack_from('<Q', data, off)[0]
def u32(off): return struct.unpack_from('<I', data, off)[0]

start = 123
pos = start
i = 0
while pos + 28 <= len(data):
    ident = u64(pos)
    lat = d(pos+8); lon = d(pos+16); tail = u32(pos+24)
    ok = (29.0 < lat < 31.5) and (111.0 < lon < 115.5) and tail == 0
    if not ok:
        print("break at record", i, "offset", pos, "id", ident, "lat", lat, "lon", lon, "tail", tail)
        print("hex", data[pos-16:pos+48].hex(' '))
        break
    pos += 28; i += 1
else:
    print("never broke")
print("records", i, "end", pos)
print("u64@115", u64(115), "count")
