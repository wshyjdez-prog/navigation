import struct, sys, collections
sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
data = open(r"D:\Navigation\example\share_for_ubuntu\test.osmx", 'rb').read()

def u32(off): return struct.unpack_from('<I', data, off)[0]
def u64(off): return struct.unpack_from('<Q', data, off)[0]
def d(off): return struct.unpack_from('<d', data, off)[0]
def rdstr(off):
    ln = u32(off); off += 4
    return data[off:off+ln].decode('utf-16-le'), off+ln

pos = 27747089  # end of nodes
wayCount = u64(pos); pos += 8
print("ways", wayCount)
tagkeys = collections.Counter()
reflens = collections.Counter()
for wi in range(wayCount):
    wid = u64(pos); pos += 8
    rc = u32(pos); pos += 4
    refs = [u64(pos + 8*k) for k in range(rc)]
    pos += 8*rc
    tc = u32(pos); pos += 4
    tags = []
    for _ in range(tc):
        k, pos = rdstr(pos); v, pos = rdstr(pos); tags.append((k,v)); tagkeys[k]+=1
    reflens[rc]+=1
print("end ways", pos, "remaining", len(data)-pos)
print("top way keys", tagkeys.most_common(25))
print("ref len hist", reflens.most_common(12))
print("after ways hex", data[pos:pos+96].hex(' '))
print("u64s", [u64(pos+8*k) for k in range(6)])
