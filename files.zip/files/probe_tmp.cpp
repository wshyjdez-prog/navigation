#include <QCoreApplication>
#include <QDebug>
#include <QDir>
#include <QTemporaryDir>

int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);
    qDebug() << "tempPath" << QDir::tempPath();
    QTemporaryDir a;
    qDebug() << "default" << a.isValid() << a.path() << a.errorString();
    QTemporaryDir b(QDir::currentPath() + "/probe-XXXXXX");
    qDebug() << "local" << b.isValid() << b.path() << b.errorString();
    return 0;
}
