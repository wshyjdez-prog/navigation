import struct, sys, collections
sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
data = open(r"D:\Navigation\example\share_for_ubuntu\test.osmx",'rb').read()
def u32(o): return struct.unpack_from('<I',data,o)[0]
def u64(o): return struct.unpack_from('<Q',data,o)[0]
def f64(o): return struct.unpack_from('<d',data,o)[0]
def rstr(o):
    n=u32(o); o+=4
    return data[o:o+n].decode('utf-16-le'), o+n

p=123
nodes={}
for i in range(912730):
    nid=u64(p); nodes[nid]=(f64(p+8),f64(p+16)); tc=u32(p+24); p+=28
    for _ in range(tc):
        k,p=rstr(p); v,p=rstr(p)
wcount=u64(p); p+=8
wayids=set(); rel_missing_way=0
routable=0; segments=0; length=0.0; area=0; access_no=0
for i in range(wcount):
    wid=u64(p); rc=u32(p+8); p+=12
    refs=[u64(p+8*k) for k in range(rc)]; p+=8*rc
    tc=u32(p); p+=4
    t={}
    for _ in range(tc):
        k,p=rstr(p); v,p=rstr(p); t[k]=v
    wayids.add(wid)
    if t.get('area')=='yes' or 'building' in t or 'landuse' in t: area+=1
    h=t.get('highway')
    if not h: continue
    if t.get('access') in ('no','private'): access_no+=1
    routable+=1
    # length
    for a,b in zip(refs,refs[1:]):
        if a==b: continue
        la,lo=nodes[a]; lb,lob=nodes[b]
        segments+=1
        # rough length
        import math
        dlat=math.radians(lb-la); dlon=math.radians(lob-lo)
        hh=math.sin(dlat/2)**2+math.cos(math.radians(la))*math.cos(math.radians(lb))*math.sin(dlon/2)**2
        length+=2*6371008.8*math.asin(math.sqrt(hh))
print('ways',wcount,'wayids',len(wayids),'highway ways',routable,'area',area,'access_no',access_no)
print('undirected segments',segments,'length km',length/1000)
rcount=u64(p); p+=8
dangling={0:0,1:0,2:0}; members={0:0,1:0,2:0}
for i in range(rcount):
    rid=u64(p); mc=u32(p+8); p+=12
    for _ in range(mc):
        t=u32(p); ref=u64(p+4); role,p=rstr(p+12)
        members[t]+=1
    tc=u32(p); p+=4
    for _ in range(tc):
        k,p=rstr(p); v,p=rstr(p)
print('members',members,'end',p)
