import struct, sys, collections
sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
data = open(r"D:\Navigation\example\share_for_ubuntu\test.osmx", 'rb').read()

def u32(off): return struct.unpack_from('<I', data, off)[0]
def u64(off): return struct.unpack_from('<Q', data, off)[0]
def rdstr(off):
    ln = u32(off); off += 4
    return data[off:off+ln].decode('utf-16-le'), off+ln

pos = 47595501
relCount = u64(pos); pos += 8
types = collections.Counter()
roles = collections.Counter()
keys = collections.Counter()
names = []
for ri in range(relCount):
    rid = u64(pos); pos += 8
    mc = u32(pos); pos += 4
    for _ in range(mc):
        t = u32(pos); pos += 4
        ref = u64(pos); pos += 8
        role, pos = rdstr(pos)
        types[t]+=1; roles[role]+=1
    tc = u32(pos); pos += 4
    for _ in range(tc):
        k, pos = rdstr(pos); v, pos = rdstr(pos)
        keys[k]+=1
        if k=='name': names.append(v)
print("relations", relCount, "end", pos, "file", len(data), "diff", len(data)-pos)
print("member types", types)
print("roles", roles.most_common(10))
print("keys", keys.most_common(15))
print("names sample", names[:10])
