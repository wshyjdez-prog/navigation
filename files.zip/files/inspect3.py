import struct, sys
sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
data = open(r"D:\Navigation\example\share_for_ubuntu\test.osmx", 'rb').read()

print("magic", data[:4], "ver", struct.unpack_from('<I', data, 4)[0])
blen = struct.unpack_from('<I', data, 8)[0]
print("strBytes", blen)
s = data[12:12+blen].decode('utf-16-le')
print("path", repr(s))
o = 12 + blen
print("after string offset", o, data[o:o+96].hex(' '))
print("u32s:", [struct.unpack_from('<I', data, o+4*k)[0] for k in range(8)])
print("i32s:", [struct.unpack_from('<i', data, o+4*k)[0] for k in range(8)])
print("doubles from", o, [struct.unpack_from('<d', data, o+8*k)[0] for k in range(6)])

# find first lat after 82
for p in range(82, 400):
    v = struct.unpack_from('<d', data, p)[0]
    if 29 < v < 32:
        nxt = struct.unpack_from('<d', data, p+8)[0]
        if 113 < nxt < 116:
            print("first latlon at", p, data[p-8:p+24].hex(' '))
            break
