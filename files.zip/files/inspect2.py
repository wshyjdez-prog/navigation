import struct, sys
sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
data = open(r"D:\Navigation\example\share_for_ubuntu\test.osmx", 'rb').read()

# scan for plausible lat/lon double pairs and compute positions
hits = []
i = 152
while i < 4000:
    try:
        a = struct.unpack_from('<d', data, i)[0]
        b = struct.unpack_from('<d', data, i+8)[0]
    except Exception:
        break
    if 29.0 < a < 32.0 and 113.0 < b < 116.0:
        hits.append(i)
    i += 1
print("first latlon positions", hits[:20])
print("diffs", [b-a for a,b in zip(hits[:20], hits[1:21])])

for p in hits[:8]:
    print(p, "id", struct.unpack_from('<Q', data, p-8)[0], "lat", struct.unpack_from('<d', data, p)[0], "lon", struct.unpack_from('<d', data, p+8)[0], "tail", data[p+16:p+24].hex(' '))
