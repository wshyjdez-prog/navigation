import struct, sys
sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
data = open(r"D:\Navigation\example\share_for_ubuntu\test.osmx",'rb').read()
def u32(o): return struct.unpack_from('<I',data,o)[0]
def u64(o): return struct.unpack_from('<Q',data,o)[0]
def f64(o): return struct.unpack_from('<d',data,o)[0]
def rstr(o):
    n=u32(o); o+=4
    return data[o:o+n].decode('utf-16-le'), o+n

p=123
for i in range(912730):
    tc=u32(p+24); p+=28
    for _ in range(tc):
        k,p=rstr(p); v,p=rstr(p)
print('nodes end',p, data[p:p+8].hex(' '))
wcount=u64(p); print('wcount',wcount); p+=8
for i in range(wcount):
    start=p
    wid=u64(p); rc=u32(p+8); p+=12
    if rc>10000 or p+8*rc>len(data):
        print('insane at way',i,'start',start,'id',wid,'rc',rc); break
    p+=8*rc
    tc=u32(p); p+=4
    if tc>200: print('insane tags at way',i,'start',start,'tc',tc); break
    for _ in range(tc):
        k,p=rstr(p); v,p=rstr(p)
else:
    print('ways end',p,'next',data[p:p+16].hex(' '))
