import struct, sys, collections, re
sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')

path = r"D:\Navigation\example\share_for_ubuntu\test.osmx"
data = open(path, 'rb').read()
print("size", len(data))
print("magic", data[:4])

def u32(off):
    return struct.unpack_from('<I', data, off)[0]

print("version", u32(4))
print("strLen?", u32(8))
slen = u32(8)
s = data[12:12+slen*2].decode('utf-16-le', errors='replace')
print("string:", repr(s))
off = 12 + slen*2
print("next offset", off)
print("hex at next:", data[off:off+128].hex(' '))
for i in range(off, off+128, 4):
    print(i, u32(i), struct.unpack_from('<f', data, i)[0], struct.unpack_from('<i', data, i)[0])

# UTF-16 string scan
u16 = collections.Counter()
for m in re.finditer(rb'(?:[\x20-\x7e]\x00){3,}', data):
    u16[m.group().decode('utf-16-le')] += 1
print("utf16 strings", len(u16))
for k, v in u16.most_common(40):
    print("  U16", v, repr(k))

u8 = collections.Counter()
for m in re.finditer(rb'[\x20-\x7e]{4,}', data):
    u8[m.group().decode('ascii')] += 1
print("utf8 strings", len(u8))
for k, v in u8.most_common(40):
    print("  U8", v, repr(k))

print("file end hex", data[-64:].hex(' '))
