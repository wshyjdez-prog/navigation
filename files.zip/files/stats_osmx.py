import struct, sys, collections, hashlib
sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
path = r"D:\Navigation\example\share_for_ubuntu\test.osmx"
data = open(path,'rb').read()

def u32(o): return struct.unpack_from('<I',data,o)[0]
def u64(o): return struct.unpack_from('<Q',data,o)[0]
def f64(o): return struct.unpack_from('<d',data,o)[0]
def rstr(o):
    n=u32(o); o+=4
    if n%2: raise ValueError('odd str')
    return data[o:o+n].decode('utf-16-le'), o+n

print('sha256', hashlib.sha256(data).hexdigest())
print('magic',data[:4],'ver',u32(4),'flags',data[82])
p=83
b=(f64(p),f64(p+8),f64(p+16),f64(p+24)); print('bounds',b)
print('file size',len(data))

p=115
ncount=u64(p); p+=8
nodes={}; dup=0; tags=0; bad=0; maxstr=0
for i in range(ncount):
    nid=u64(p); lat=f64(p+8); lon=f64(p+16); tc=u32(p+24); p+=28
    if nid in nodes: dup+=1
    nodes[nid]=(lat,lon)
    if not(29<=lat<=31 and 111<=lon<=115): bad+=1
    for _ in range(tc):
        k,p=rstr(p); v,p=rstr(p); tags+=1; maxstr=max(maxstr,len(k),len(v))
print('nodes',ncount,'unique',len(nodes),'dup',dup,'tags',tags,'badcoords',bad,'maxstr',maxstr)
print('node bounds', min(v[0] for v in nodes.values()), min(v[1] for v in nodes.values()), max(v[0] for v in nodes.values()), max(v[1] for v in nodes.values()))

wcount=u64(p); p+=8
ways=[]; wdup=0; wtags=0; missing=0; one=0; zeroref=0; maxref=0; names=0; highway=0
classes=collections.Counter(); oneway=collections.Counter(); missingways=0
for i in range(wcount):
    wid=u64(p); rc=u32(p+8); p+=12
    refs=[u64(p+8*k) for k in range(rc)]; p+=8*rc
    tc=u32(p); p+=4
    t={}
    for _ in range(tc):
        k,p=rstr(p); v,p=rstr(p); t[k]=v; wtags+=1
    ways.append((wid,refs,t))
    if rc==0: zeroref+=1
    maxref=max(maxref,rc)
    miss=sum(1 for r in refs if r not in nodes)
    if miss:
        missing+=miss; missingways+=1
    h=t.get('highway')
    if h: highway+=1; classes[h]+=1
    ow=t.get('oneway'); oneway[ow or '']+=1
print('ways',wcount,'tags',wtags,'missingrefs',missing,'missingways',missingways,'zeroref',zeroref,'maxref',maxref)
print('highway ways',highway,'classes',classes.most_common(20))
print('oneway',oneway.most_common(8))

rcount=u64(p); p+=8
rels=[]; rdup=0; members=0; mtypes=collections.Counter(); dangling=0; rmaxstr=0
for i in range(rcount):
    rid=u64(p); mc=u32(p+8); p+=12
    ms=[]
    for _ in range(mc):
        t=u32(p); ref=u64(p+4); role,p=rstr(p+12)
        ms.append((t,ref,role)); members+=1; mtypes[t]+=1
        if t==0 and ref not in nodes: dangling+=1
    tc=u32(p); p+=4
    for _ in range(tc):
        k,p=rstr(p); v,p=rstr(p); rmaxstr=max(rmaxstr,len(k),len(v))
    rels.append((rid,ms))
print('relations',rcount,'members',members,'types',mtypes,'dangling node members',dangling,'maxstr',rmaxstr)
print('end',p,'size',len(data),'trailing',len(data)-p)
print('relation first', rels[0][0], rels[0][1][:2])
