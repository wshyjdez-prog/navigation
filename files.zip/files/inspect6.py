import struct, sys, collections
sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
data = open(r"D:\Navigation\example\share_for_ubuntu\test.osmx", 'rb').read()
n = len(data)

def u32(off): return struct.unpack_from('<I', data, off)[0]
def u64(off): return struct.unpack_from('<Q', data, off)[0]
def d(off): return struct.unpack_from('<d', data, off)[0]
def rdstr(off):
    ln = u32(off); off += 4
    s = data[off:off+ln].decode('utf-16-le'); return s, off+ln

def skip_tags(off, cnt):
    for _ in range(cnt):
        k, off = rdstr(off)
        v, off = rdstr(off)
        yield k, v, off

pos = 123
nodeCount = u64(115)
print("declared nodes", nodeCount)
keys = collections.Counter()
vals = collections.Counter()
tagged = 0
for i in range(nodeCount):
    ident = u64(pos); lat = d(pos+8); lon = d(pos+16); cnt = data[pos+24] if False else u32(pos+24)
    pos += 28
    if cnt:
        tagged += 1
    for k, v, pos2 in skip_tags(pos, cnt):
        keys[k]+=1; vals[(k,v)]+=1; pos = pos2
print("parsed nodes", nodeCount, "tagged", tagged, "end", pos)
print("top keys", keys.most_common(15))
print("bytes after nodes", data[pos:pos+80].hex(' '))
print("u64s", [u64(pos+8*k) for k in range(6)])
print("i32s", [struct.unpack_from('<i', data, pos+4*k)[0] for k in range(8)])
