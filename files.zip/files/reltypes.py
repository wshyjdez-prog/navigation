import struct, sys, collections
sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
data = open(r"D:\Navigation\example\share_for_ubuntu\test.osmx",'rb').read()
def u32(o): return struct.unpack_from('<I',data,o)[0]
def u64(o): return struct.unpack_from('<Q',data,o)[0]
def f64(o): return struct.unpack_from('<d',data,o)[0]
def rstr(o):
    n=u32(o); o+=4
    return data[o:o+n].decode('utf-16-le'), o+n
p=123
nodes=set()
for i in range(912730):
    nodes.add(u64(p)); tc=u32(p+24); p+=28
    for _ in range(tc):
        k,p=rstr(p); v,p=rstr(p)
wc=u64(p); p+=8
ways=set()
for i in range(wc):
    wid=u64(p); rc=u32(p+8); p+=12
    ways.add(wid); p+=8*rc
    tc=u32(p); p+=4
    for _ in range(tc):
        k,p=rstr(p); v,p=rstr(p)
rcount=u64(p); p+=8
rels=set(); members=[]
for i in range(rcount):
    rid=u64(p); mc=u32(p+8); p+=12
    rels.add(rid)
    for _ in range(mc):
        t=u32(p); ref=u64(p+4); role,p=rstr(p+12)
        members.append((t,ref,role))
    tc=u32(p); p+=4
    for _ in range(tc):
        k,p=rstr(p); v,p=rstr(p)
print('rel count',len(rels),'members',len(members))
for t in (0,1,2):
    sub=[m for m in members if m[0]==t]
    print('type',t,'n',len(sub),
          'in nodes',sum(1 for m in sub if m[1] in nodes),
          'in ways',sum(1 for m in sub if m[1] in ways),
          'in rels',sum(1 for m in sub if m[1] in rels))
# sample
for t in (0,1,2):
    print(t, [m for m in members if m[0]==t][:3])
