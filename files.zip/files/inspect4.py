import struct, sys
sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
data = open(r"D:\Navigation\example\share_for_ubuntu\test.osmx", 'rb').read()

def d(off): return struct.unpack_from('<d', data, off)[0]
def u64(off): return struct.unpack_from('<Q', data, off)[0]
def u32(off): return struct.unpack_from('<I', data, off)[0]

print("byte82", data[82])
print("bounds", d(83), d(91), d(99), d(107))
print("u64@115", u64(115))
print("u64@123", u64(123), "lat", d(123+8), "lon", d(123+16), "tail", u32(123+24))

n = u64(115)
print("n", n, "node section", 123, "->", 123+n*28, "len", n*28)
end = 123 + n*28
print("bytes at end", data[end:end+64].hex(' '))
print("u64s at end", [u64(end+8*k) for k in range(6)])
print("i32s at end", [struct.unpack_from('<i', data, end+4*k)[0] for k in range(10)])
