#include "app/ImportPage.h"
#include "app/MainWindow.h"
#include "data/osmx/OsmxStore.h"
#include "ui/common/Theme.h"

#include <QApplication>
#include <QDir>
#include <QTemporaryDir>
#include <QTimer>
#include <QtDebug>

using namespace p1;

int main(int argc, char** argv) {
    QApplication app(argc, argv);
    const QStringList args = QCoreApplication::arguments();
    if (args.size() < 2) {
        qCritical("usage: import-smoke <file.osmx>");
        return 2;
    }
    QTemporaryDir cache(QDir::currentPath() + QStringLiteral("/smoke-cache-XXXXXX"));
    if (!cache.isValid()) {
        qCritical("cannot create cache directory: %s", qPrintable(cache.errorString()));
        return 2;
    }

    ui::Theme theme;
    theme.apply(app);
    app::MainWindow window(theme, nullptr, cache.path());
    window.show();

    // The application shell must register the page under the stable ID
    // "import"; the smoke fails here if the factory contract regressed.
    if (window.currentPageId() != QLatin1String("import")) {
        qCritical("import page is not the current page: %s", qPrintable(window.currentPageId()));
        return 2;
    }
    auto* page = window.findChild<app::ImportPage*>();
    if (page == nullptr) {
        qCritical("MainWindow did not register the ImportPage");
        return 2;
    }
    qInfo("registered page id=import class=%s", page->metaObject()->className());

    QObject::connect(page, &app::ImportPage::importFinished, &app,
                     [&app, page](const app::ImportResult& result) {
                         qInfo("finished ok=%d cancelled=%d elapsed=%lld ms", int(result.ok),
                               int(result.cancelled), static_cast<long long>(result.elapsedMs));
                         if (!result.error.isEmpty()) qInfo("error: %s", qPrintable(result.error));
                         qInfo("nodes=%llu ways=%llu relations=%llu routable=%llu edges=%llu tags=%llu",
                               static_cast<unsigned long long>(result.stats.nodes),
                               static_cast<unsigned long long>(result.stats.ways),
                               static_cast<unsigned long long>(result.stats.relations),
                               static_cast<unsigned long long>(result.stats.routableWays),
                               static_cast<unsigned long long>(result.stats.directedEdges),
                               static_cast<unsigned long long>(result.stats.tags));
                         qInfo("cache=%s", qPrintable(result.cachePath));
                         const auto dataset = data::OsmxStore::shared().active();
                         if (dataset) {
                             qInfo("store active id=%s ways=%u edges=%u", qPrintable(dataset->info().datasetId),
                                   dataset->wayCount(), dataset->info().directedEdgeCount);
                         } else {
                             qInfo("store has no active dataset");
                         }
                         for (const auto& warning : result.warnings) qInfo("warning: %s", qPrintable(warning));
                         qInfo("importing=%d", int(page->isImporting()));
                         app.exit(result.ok && dataset ? 0 : 1);
                     });
    QTimer::singleShot(180000, &app, [&app] {
        qCritical("timeout");
        app.exit(3);
    });

    qInfo("selecting %s", qPrintable(args.at(1)));
    page->selectFile(args.at(1));
    page->startImport();
    return app.exec();
}
