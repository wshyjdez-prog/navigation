#include "data/import/OsmImportParser.h"

#include "contracts/ImportedDataset.h"

#include <QDir>
#include <QFileInfo>
#include <QStandardPaths>

namespace p1::data {

OsmImportParser::OsmImportParser(QString cacheDirectory) : directory_(std::move(cacheDirectory)) {}

QString OsmImportParser::inputFormat(const QString& path) {
    const QString name = QFileInfo(path).fileName().toLower();
    if (name.endsWith(".osm.gz")) return "osm.gz";
    if (name.endsWith(".osm.bz2")) return "osm.bz2";
    if (name.endsWith(".pbf")) return "pbf";
    if (name.endsWith(".osm")) return "osm";
    return {};
}

app::ImportResult OsmImportParser::parse(const QString&, const app::ImportProgressCallback&,
                                         const app::ImportLogCallback&,
                                         const app::ImportCancelCallback&) const {
    app::ImportResult result;
    result.error = QStringLiteral("stub parser cannot import standard OSM in this smoke build");
    return result;
}

QString defaultImportCacheDirectory() {
    return QDir::currentPath() + QStringLiteral("/imports");
}

QVector<app::ImportResult> listImportedDatasets(const QString& directory) {
    Q_UNUSED(directory);
    return {};
}

} // namespace p1::data
