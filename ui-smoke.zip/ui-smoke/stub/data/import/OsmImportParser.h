#pragma once

#include "app/ImportParser.h"

namespace p1::data {

// Local smoke-test stub for the libosmium parser, which is not available on the
// development host. It exists only in .scratch and is not part of the project.
class OsmImportParser final : public app::ImportParser {
public:
    explicit OsmImportParser(QString cacheDirectory = {});
    static QString inputFormat(const QString& path);
    QString name() const override { return QStringLiteral("stub osm"); }
    QStringList extensions() const override { return {"osm", "pbf"}; }
    app::ImportResult parse(const QString&, const app::ImportProgressCallback&,
                            const app::ImportLogCallback&, const app::ImportCancelCallback&) const override;

private:
    QString directory_;
};

} // namespace p1::data
